<!DOCTYPE html>
<html>
<head>
	<title>Super Cacl Max</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
	<? include "topo.php";?>
	<div class='corpo'>
		<div class='titulo'>Calculos Esportivos</div>
		<div class='item'>
			<a href="calculo_imc.php">Cálculo de IMC</a>
		</div>
		<div class='item'>
			<a href="calculo_calorias.php">Calculo de Calorias</a>
		</div>
		<div class="limpar"></div>
	</div>

	<div class='corpo'>
		<div class='titulo'>Calculos Medidas</div>
		<div class='item2'>
			<a href="distancia.php">Distância</a>
		</div>
		<div class='item2'>
			Calculadora de IMC
		</div>
		<div class='item2'>
			Calculadora de IMC
		</div>
		<div class='item2'>
			Calculadora de IMC
		</div>

		<div class='item2'>
			Calculadora de IMC
		</div>
		<div class='item2'>
			Calculadora de IMC
		</div>
		<div class='item2'>
			Calculadora de IMC
		</div>
		<div class='item2'>
			Calculadora de IMC
		</div>
		<div class="limpar"></div>
	</div>	
</body>
</html>