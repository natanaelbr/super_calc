<div class="topo">
	<h1>SUPERCALC MAX</h1>
	<a href="index.php">Página Inicial</a> | 
	<a href="#">Sobre</a>
</div>